;(function () {
    var app = function () {
        this.access_token = localStorage.access_token || false;

    };
    app.prototype.init = function () {

    };
}());