;(function () {
    
    $.init = function () {
        $.main();
    };
}());